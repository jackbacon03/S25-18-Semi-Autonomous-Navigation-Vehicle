/*
 * Copyright (c) 2020 Arduino.  All rights reserved.
 */

/**************************************************************************************
   INCLUDE/MAIN
 **************************************************************************************/

#define CATCH_CONFIG_MAIN
#include <catch2/catch_test_macros.hpp>
